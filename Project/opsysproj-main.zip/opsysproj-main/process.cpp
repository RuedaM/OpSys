#include "everything.h"

Process::Process(const int i, const Arguments &args)
	: name(i + 65),
	  isIO(i < args.n - args.ncpu),
	  arrivalTime(std::floor(next_exp(args))),
	  numCpuBursts(std::ceil(drand48() * 64)),
	  totalBursts(2 * numCpuBursts - 1),
	  initialTau(std::ceil(1 / args.lambda)),
	  bursts(new int[totalBursts])
{
	/*
	 * burst initialization
	 * p->bursts contains the cpu and i/o bursts interleaving
	 * that is, bursts[0] is a cpu burst, bursts[1] is an i/o burst, so on
	 */

	const auto ceilNextExp = [args]()
	{ return std::ceil(next_exp(args)); };

	const auto pushBurst = [this, ceilNextExp](bool burstIsIo)
	{
		if (this->isIO)
		{
			if (!burstIsIo)
				this->pushBurst(ceilNextExp());
			else
				this->pushBurst(ceilNextExp() * 10);
		}
		else
		{
			if (!burstIsIo)
				this->pushBurst(ceilNextExp() * 4);
			else
				this->pushBurst(std::floor(ceilNextExp() / 8 * 10));
		}
	};

	for (int j = 0; j < numCpuBursts - 1; ++j)
	{
		pushBurst(false);
		pushBurst(true);
	}
	pushBurst(false);

	cpuBurstTimeSum = 0;
	for (int i = 0; i < totalBursts; i += 2)
		cpuBurstTimeSum += bursts[i];

	resetVariables();
}

Process::~Process()
{
	delete[] bursts;
}

void Process::resetVariables()
{
	state = 0;
	runningUntil = -1;
	waitingUntil = -1;
	switchingUntil = -1;
	burstIndex = 0;
	tau = initialTau;
	timeRemaining = 0;
	turnaroundTimeSum = 0;
}
