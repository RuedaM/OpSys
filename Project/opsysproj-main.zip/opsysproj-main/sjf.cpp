/*
For the SJF and SRT algorithms, since we cannot know the actual CPU burst
times beforehand, we will rely on estimates determined via exponential averaging. As such,
this command-line argument is the constant α. Note that the initial guess for each process
is τ0 = 1/λ. When calculating τ values, use the “ceiling” function for all calculations.

Recalculate it after each CPU Burst wiht this formula:
==================================================
tau     =  alpha  x  t    +   (1-alpha)  x  tau
	i+1                i                        i
==================================================

BTW: tau = predicted CPU Burst Time.

queues are sorted by tau (least to greatest), then arrivalTime, alphabetical order.

- alpha is argv[7]
- λ is argv[4]
- contextSwitchTime is arg[6]. First half of the contextSwitchTime
  is the time required to remove the give process form the CPU and the
  second half is used to bring the next one in. Expect this to be positive
  and even. Note the tricky part under this.

  time 26ms: Process C arrived; added to ready queue [Q C]
  time 28ms: Process C started using the CPU for 2920ms burst [Q <empty>]
  # Takes 2ms to come in

  time 2948ms: Process C switching out of CPU; blocking on I/O until time 3318ms [Q A B]
  time 2952ms: Process A started using the CPU for 1330ms burst [Q B]
  # Takes 2ms for C to switch out, and another 2 for A to come in.
*/

#include "sjf_srt.h"

void sjf(const Arguments &args, const std::list<Process *> &processes, AlgorithmMeasurements &measurements)
{
	// Running Process
	Process *runningProcess = NULL;

	// Current Process being worked on
	Process *p;

	// Ready Queue
	SjfReadyQueue readyQueue;

	// Resetting the state.
	for (const auto p : processes)
	{
		p->state = NOTINCPU;
		p->runningUntil = -1;
		p->waitingUntil = -1;
		p->burstIndex = 0;
		p->tau = p->initialTau;
		p->turnaroundTimeSum = 0;
	}

	// Current time of the simulation
	currentTime = 0;
	int halfTime = args.contextSwitchTime / 2;

	// Simulator Starts.
	std::cout << "time 0ms: Simulator started for SJF [Q <empty>]" << '\n';

	// While the processes are not all complete.
	while (!all_completed(processes))
	{
		if (!readyQueue.empty() && runningProcess == NULL)
		{
			if (!(p->state == WAITING && earliestEventTime(p) == currentTime))
			{
				runningProcess = readyQueue.top();
				readyQueue.pop(); 
			}
		}

		p = earliestEventProcess(processes, runningProcess);

		switch (p->state)
		{
		// If the below code runs, it is time for process p to arrive.
		// Its state will be set to READY, and it will be pushed into readyQueue.
		case NOTINCPU:
			p->state = READY;
			readyQueue.push(p);
			currentTime = p->arrivalTime;
			p->beginTurnaround(currentTime);
			if (currentTime < 10000)
				std::cout << "time " << currentTime << "ms: Process " << p->name << " (tau " << p->tau << "ms) arrived; added to ready queue " << readyQueue << '\n';
			break;

		// If the below code runs, p MUST be at the top of readyQueue.
		// Its state will be set to SWITCHING_IN, but it will stay in readyQueue until it has fully switched in.
		case READY:
			p->state = SWITCHING_IN;
			p->switchingUntil = currentTime + halfTime;
			break;

		// The most complex operation happens here.
		// Process has finished running its CPU burst.
		// Now it will either go into the COMPLETED or SWITCHING_OUT state, based on whether it has bursts left to run.
		case RUNNING:
			currentTime = p->runningUntil;

			if (p->burstIndex >= p->totalBursts)
			{
				p->state = COMPLETED;
				std::cout << "time " << currentTime << "ms: Process " << p->name << " terminated " << readyQueue << '\n';
				currentTime += halfTime;
				runningProcess = NULL;
				p->endTurnaround(currentTime);
				measurements.numContextSwitches.countOne(p);
			}
			else
			{
				p->state = SWITCHING_OUT;
				p->burstIndex++;

				// Calculate remaining bursts
				int burstsLeft = p->numCpuBursts - p->burstIndex / 2;
				if (currentTime < 10000)
					std::cout << "time " << currentTime << "ms: Process " << p->name << " (tau " << p->tau << "ms) completed a CPU burst; " << burstsLeft << " burst" << ((burstsLeft == 1) ? "" : "s") << " to go " << readyQueue << '\n';

				// Previous bursts
				int prevIOBurst = p->bursts[p->burstIndex - 1];
				int prevCPUBurst = p->bursts[p->burstIndex - 2];

				// Calculating time until it stops waiting and goes back to ready queue.
				p->waitingUntil = currentTime + prevIOBurst + halfTime;

				// Recalc tau
				int oldTau = p->tau;
				p->tau = std::ceil(args.alpha * prevCPUBurst + (1.0 - args.alpha) * oldTau);

				if (currentTime < 10000)
					std::cout << "time " << currentTime << "ms: Recalculating tau for process " << p->name << ": old tau " << oldTau << "ms ==> new tau " << p->tau << "ms " << readyQueue << '\n';

				if (currentTime < 10000)
					std::cout << "time " << currentTime << "ms: Process " << p->name << " switching out of CPU; blocking on I/O until time " << p->waitingUntil << "ms " << readyQueue << '\n';

				p->switchingUntil = currentTime + halfTime;
			}
			break;

		// Process has finished switching into the CPU.
		// Now it will go into the RUNNING state, and (runningProcess == p) must be true.
		case SWITCHING_IN:
			p->state = RUNNING;
			currentTime = p->switchingUntil;
			if (currentTime < 10000)
				std::cout << "time " << currentTime << "ms: Process " << p->name << " (tau " << p->tau << "ms) started using the CPU for " << p->bursts[p->burstIndex] << "ms burst " << readyQueue << '\n';
			p->runningUntil = p->switchingUntil + p->bursts[p->burstIndex++];
			break;

		// Process has finished switching out of the CPU.
		// Now it will go into the WAITING state, and (runningProcess == NULL) must be true.
		case SWITCHING_OUT:
			p->state = WAITING;
			currentTime = p->switchingUntil;
			p->endTurnaround(currentTime);
			runningProcess = NULL;
			measurements.numContextSwitches.countOne(p);
			break;

		// Process has finished its I/O burst.
		// Now it will go into the READY state, and will be pushed into readyQueue.
		// For SRT, preemption should be handled here.
		case WAITING:
			p->state = READY;
			readyQueue.push(p);
			currentTime = p->waitingUntil;
			p->beginTurnaround(currentTime);
			if (currentTime < 10000)
				std::cout << "time " << currentTime << "ms: Process " << p->name << " (tau " << p->tau << "ms) completed I/O; added to ready queue " << readyQueue << '\n';
		}
	}

	std::cout << "time " << currentTime << "ms: Simulator ended for SJF [Q <empty>]\n";

	measurements.timeElapsed = currentTime;
}
