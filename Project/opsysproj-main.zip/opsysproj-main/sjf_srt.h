#include "everything.h"

// sjf/srt specific states
enum
{
	SWITCHING_IN,
	RUNNING,
	WAITING,
	SWITCHING_OUT,
	READY,
	NOTINCPU,
	COMPLETING,
	COMPLETED
};

struct SjfBurstComparer
{
	bool operator()(const Process *const, const Process *const) const;
};

struct SrtBurstComparer
{
	bool operator()(const Process *const, const Process *const) const;
};

typedef std::priority_queue<Process *, std::vector<Process *>, SjfBurstComparer> SjfReadyQueue;
typedef std::priority_queue<Process *, std::vector<Process *>, SrtBurstComparer> SrtReadyQueue;


// these override allows you to shove readyQueue in a std::cout one-liner
std::ostream &operator<<(std::ostream &, SjfReadyQueue);
std::ostream &operator<<(std::ostream &, SrtReadyQueue);

// checks if each process's state is COMPLETED
bool all_completed(const std::list<Process *> &);

extern int currentTime;

// get the earliest event time based on p->state
int earliestEventTime(const Process *const);

// returns the process whose earliest event is the next one to occur out of all processes
Process *earliestEventProcess(const std::list<Process *> &, Process *const);
