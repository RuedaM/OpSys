#include "everything.h"

Arguments::Arguments(const char *const *const argv)
	: n(std::atoi(argv[1])),
	  ncpu(std::atoi(argv[2])),
	  seed(std::atoi(argv[3])),
	  lambda(std::atof(argv[4])),
	  upperThreshold(std::atoi(argv[5])),
	  contextSwitchTime(std::atoi(argv[6])),
	  alpha((float)std::atof(argv[7])),
	  timeSliceValue(std::atoi(argv[8]))
{
}

void AlgorithmMeasurements::reset()
{
	timeElapsed = 0;
	numContextSwitches = {0, 0, 0};
	numPreemptions = {0, 0, 0};
}

void Average3::calcAverages(const Total3 &sum, const Total3 &total)
{
	forAllProcesses = (double)sum.forAllProcesses / (double)total.forAllProcesses;
	forIoProcesses = (total.forIoProcesses == 0) ? 0 : (double)sum.forIoProcesses / (double)total.forIoProcesses;
	forCpuProcesses = (total.forCpuProcesses == 0) ? 0 : (double)sum.forCpuProcesses / (double)total.forCpuProcesses;
}

void Average3::roundAllTo3Places()
{
	forAllProcesses = std::ceil(forAllProcesses * 1000) / 1000;
	forIoProcesses = std::ceil(forIoProcesses * 1000) / 1000;
	forCpuProcesses = std::ceil(forCpuProcesses * 1000) / 1000;
}

void Total3::countOne(const Process *const p)
{
	++forAllProcesses;
	if (p->isIO)
		++forIoProcesses;
	else
		++forCpuProcesses;
}
