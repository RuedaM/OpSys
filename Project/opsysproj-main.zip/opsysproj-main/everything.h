#ifndef __EVERYTHING__
#define __EVERYTHING__

#include <stdio.h>
#include <limits>
#include <cmath>
#include <algorithm>
#include <string>
#include <iostream>
#include <list>
#include <cctype>
#include <queue>
#include <vector>
#include <map>
#include <set>
#include <fstream>
#include <iomanip>

struct Arguments
{
	const int n;
	const int ncpu;
	const int seed;
	const double lambda;
	const int upperThreshold;
	const int contextSwitchTime;
	const float alpha;
	const int timeSliceValue;

	Arguments(const char *const *const argv);
};

struct Process;

struct Total3
{
	int forIoProcesses = 0,
		forCpuProcesses = 0,
		forAllProcesses = 0;

	void countOne(const Process *const p);
};

struct Average3
{
	double forIoProcesses,
		forCpuProcesses,
		forAllProcesses;

	void calcAverages(const Total3 &sum, const Total3 &total);
	void roundAllTo3Places();
};

struct AlgorithmMeasurements
{
	int timeElapsed;
	Total3 numContextSwitches;
	Total3 numPreemptions;

	void reset();
};

// from part2.cpp
double next_exp(const Arguments &args);

struct Process
{
	// constants
	const char name;
	const bool isIO;
	const int arrivalTime,
		numCpuBursts,
		totalBursts,
		initialTau;

	// burst arrays
	int *const bursts;

	// algorithm variables
	int burstIndex,
		runningUntil,
		waitingUntil,
		switchingUntil,
		timeRemaining,
		tau,
		currentTau,
		state;

	// measurement variables
	int cpuBurstTimeSum;
	float avgCpuBurstTime;
	int turnaroundTimeSum, turnaroundTemp;
	int numPreemptions;

	Process(const int i, const Arguments &args);
	~Process();

	// also increments burstIndex
	inline void pushBurst(const int burstTime)
	{
		bursts[burstIndex++] = burstTime;
	}

	inline void beginTurnaround(int currentTime)
	{
		turnaroundTemp = currentTime;
	}

	inline void endTurnaround(int currentTime)
	{
		turnaroundTimeSum += currentTime - turnaroundTemp;
	}

	void resetVariables();
};

#endif
