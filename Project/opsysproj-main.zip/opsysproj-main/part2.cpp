#include "everything.h"

// you don't need to comment these out, only comment out the calls
void FCFS(const std::list<Process *> &processes, const Arguments *const args, AlgorithmMeasurements &measurements);
void sjf(const Arguments &args, const std::list<Process *> &processes, AlgorithmMeasurements &measurements);
void srt(const Arguments &args, const std::list<Process *> &processes, AlgorithmMeasurements &measurements);
void RR(const std::list<Process *> &p, const Arguments *const args, AlgorithmMeasurements &measurements);

double next_exp(const Arguments &args)
{
	auto x = std::numeric_limits<double>::max();
	while (x > args.upperThreshold)
		x = -std::log(drand48()) / args.lambda;
	return x;
}

void part1_print_processes(const std::list<Process *> &processes, const Arguments &args)
{
	printf("<<< PROJECT PART I -- process set (n=%d) with %d CPU-bound process%s >>>\n", args.n, args.ncpu, (args.ncpu != 1) ? "es" : "");

	for (const auto p : processes)
	{
		printf("%s-bound process %c: arrival time %dms; %d CPU bursts\n", p->isIO ? "I/O" : "CPU", p->name, p->arrivalTime, p->numCpuBursts);
	}
}

// from measurements.cpp
void process_measurements(const std::list<Process *> &processes, AlgorithmMeasurements &measurements, const char *const algorithmName, const Arguments &args);
void calc_avg_cpu_burst_time(const std::list<Process *> &processes);

// used in measurements.cpp
std::ofstream simout("simout.txt");

int main(const int argc, const char *const *const argv)
{
	// change to error later
	if (argc != 9)
	{
		fprintf(stderr, "ERROR: insufficient command-line arguments :(\n");
		return EXIT_FAILURE;
	}

	// get and format command line args
	const Arguments args(argv);

	// set the seed for random generation
	srand48(args.seed);

	// allocate the array
	std::list<Process *> processes;

	for (auto i = 0; i < args.n; ++i)
	{
		Process *const p = new Process(i, args);
		processes.push_back(p);
	}

	calc_avg_cpu_burst_time(processes);

	// part 1
	part1_print_processes(processes, args);

	// part 2
	printf("\n<<< PROJECT PART II -- t_cs=%dms; alpha=%0.2lf; t_slice=%dms >>>\n", args.contextSwitchTime, args.alpha, args.timeSliceValue);

	AlgorithmMeasurements measurements;

	FCFS(processes, &args, measurements);
	process_measurements(processes, measurements, "FCFS", args);

	std::cout << '\n';
	
	sjf(args, processes, measurements);
	process_measurements(processes, measurements, "SJF", args);
	
	std::cout << '\n';
	
	srt(args, processes, measurements);
	process_measurements(processes, measurements, "SRT", args);
	
	std::cout << '\n';
	
	RR(processes, &args, measurements);
	process_measurements(processes, measurements, "RR", args);

	simout.close();

	// memory cleanup
	for (const auto p : processes)
		delete p;
}
