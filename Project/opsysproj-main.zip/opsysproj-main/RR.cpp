#include "everything.h"
using namespace std;

/* moved here from everything.hpp since only your ass uses it */

#define INTLIMIT numeric_limits<int>::max()

enum
{
	NOTINPROC,
	READY,
	RUNNING,
	WAITING,
	PREEMPTED,
	SWITCHINGOUT
};

const char *queueToStr(const list<Process *> &readyQueue, bool omitFIQ = false)
{
	if (readyQueue.size() == 0)
	{
		return "[Q <empty>]";
	}

	printf("[Q ");
	int i = 0;

	// the thing at the front of the ready queue is currently switching

	for (Process *p : readyQueue)
	{
		i++;
		if (omitFIQ && i == 1)
			continue;
		printf("%c", p->name);
		if (i != (int)readyQueue.size())
			printf(" ");
	}

	return "]";
}

struct RRCompareProcessPointers
{
	bool operator()(const Process *p1, const Process *p2) const
	{
		if (p1->burstIndex == -1 && p2->burstIndex == -1)
			return p1->arrivalTime < p2->arrivalTime;

		if (p1->waitingUntil != p2->waitingUntil)
			return p1->waitingUntil > p2->waitingUntil;
		return p1->name > p2->name;
	}
};

void RR(const list<Process *> &p, const Arguments *const args, AlgorithmMeasurements &measurements)
{
	bool debug = false;

	list<Process *> readyQueue, unarrived(p);
	priority_queue<Process *, vector<Process *>, RRCompareProcessPointers> waitingQueue;
	Process *runningProc = NULL;
	Process *switchingProc = NULL;

	for (auto p : unarrived)
	{
		p->resetVariables();
		p->burstIndex = -1;
	}

	struct
	{
		int io = 0, cpu = 0;
	} numPreemptions;

	int cswitches = 0;
	int csTimeSplit = args->contextSwitchTime / 2;

	int sysClock = 0;

	unarrived.sort(RRCompareProcessPointers());

	printf("time 0ms: Simulator started for RR [Q <empty>]\n");
	Process *smallestProc;
	int smallestTime;

	while (runningProc != NULL || unarrived.size() || readyQueue.size() || waitingQueue.size())
	{
		// find the next process to do something
		if (unarrived.size() > 0)
		{
			smallestProc = unarrived.front();
			smallestTime = unarrived.front()->arrivalTime - sysClock;

			if (sysClock > unarrived.front()->arrivalTime)
			{
				sysClock = unarrived.front()->arrivalTime;
				smallestTime = 0;
			}
		}
		else
		{
			smallestProc = NULL;
			smallestTime = INTLIMIT;
		}

		// check the ready queueueueueueueueeueueueueeue
		if ((runningProc == NULL && readyQueue.size() > 0 && csTimeSplit <= smallestTime))
		{
			smallestProc = readyQueue.front();
			smallestTime = csTimeSplit;
		}

		// check the waiting queueueueueeueueueueue
		if (waitingQueue.size() > 0 && (waitingQueue.top()->waitingUntil - sysClock) < smallestTime)
		{
			smallestTime = waitingQueue.top()->waitingUntil - sysClock;
			smallestProc = waitingQueue.top();
		}

		// check if the thing running has shorter time
		if (runningProc != NULL && (runningProc->runningUntil - sysClock + csTimeSplit) <= smallestTime)
		{
			smallestTime = runningProc->runningUntil - sysClock + csTimeSplit;
			smallestProc = runningProc;
		}

		// RR stuff
		if (runningProc && runningProc->state == PREEMPTED && (runningProc->runningUntil - sysClock) <= smallestTime)
		{
			smallestProc = runningProc;
			smallestTime = runningProc->runningUntil - sysClock;
		}

		// get around a process coming out of I/O and ignoring context-switch time
		if (waitingQueue.size() > 0 && waitingQueue.top()->waitingUntil < sysClock)
		{
			sysClock = waitingQueue.top()->waitingUntil;
			smallestProc = waitingQueue.top();
			smallestTime = 0;
		}

		if (switchingProc && switchingProc->switchingUntil - sysClock <= smallestTime)
		{
			smallestProc = switchingProc;
			smallestTime = switchingProc->switchingUntil - sysClock;
		}

		// DEBUG STATEMENT REMOVE LATER
		if (smallestTime < 0)
		{
			cerr << "sysClock: " << sysClock << "\t\tsmallestTime: " << smallestTime << "\t\tname: " << smallestProc->name << "\t\tstate: " << smallestProc->state << "\t\tind: " << smallestProc->runningUntil << endl;
			cerr << "smallestInd: " << smallestProc->burstIndex << "\t\tsmallestBurst: " << smallestProc->bursts[smallestProc->burstIndex] << endl;
			cerr << "waitingQTop: " << waitingQueue.top()->name << "\t\twaitingQUntil: " << waitingQueue.top()->waitingUntil << "\t\tswitchingUntil: " << smallestProc->switchingUntil << "\n\n";
			break;
		}

		// deal with whatever the event is
		switch (smallestProc->state)
		{
		case NOTINPROC:
		{
			sysClock = smallestProc->arrivalTime;
			smallestProc->switchingUntil = sysClock + csTimeSplit;

			// move the process into the ready queue
			readyQueue.push_back(smallestProc);
			smallestProc->beginTurnaround(sysClock);
			unarrived.pop_front();
			smallestProc->state = READY;
			bool omitFIQ = (readyQueue.front()->switchingUntil > sysClock) && (readyQueue.front()->switchingUntil - csTimeSplit < sysClock);

			std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " arrived; added to ready queue " << queueToStr(readyQueue, omitFIQ) << '\n';
			break;
		}

		case READY:
			// move the CPU (checking is done earlier)
			readyQueue.pop_front();
			runningProc = smallestProc;
			runningProc->state = RUNNING;
			runningProc->burstIndex++;
			sysClock = smallestProc->switchingUntil;
			cswitches += 1;

			if (debug || sysClock < 10000)
			{
				std::cout << "time " << smallestProc->switchingUntil << "ms: Process " << smallestProc->name << " started using the CPU for " << smallestProc->bursts[smallestProc->burstIndex] << "ms burst " << queueToStr(readyQueue) << '\n';
			}

			// first time in the queue
			if (smallestProc->bursts[smallestProc->burstIndex] > args->timeSliceValue)
			{
				runningProc->timeRemaining = smallestProc->bursts[smallestProc->burstIndex];
				runningProc->runningUntil = sysClock + args->timeSliceValue;
				runningProc->state = PREEMPTED;
			}
			else
				smallestProc->runningUntil = sysClock + smallestProc->bursts[smallestProc->burstIndex];

			break;

		case RUNNING:
			sysClock = smallestProc->runningUntil;
			smallestProc->burstIndex++;
			measurements.numContextSwitches.countOne(smallestProc);

			if ((int)smallestProc->totalBursts <= smallestProc->burstIndex)
			{
				// exit the process
				smallestProc->endTurnaround(sysClock);
				std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " terminated " << queueToStr(readyQueue) << '\n';
			}
			else if (smallestProc->timeRemaining > 0)
			{
				smallestProc->state = PREEMPTED;
				readyQueue.push_back(smallestProc);
			}
			else
			{
				smallestProc->endTurnaround(sysClock);
				runningProc->state = WAITING;
				smallestProc->waitingUntil = sysClock + smallestProc->bursts[smallestProc->burstIndex] + csTimeSplit;

				// move the process to either I/O wait (no CPU bc they alternate)
				waitingQueue.push(runningProc);

				if (debug || sysClock < 10000)
				{
					int btg = smallestProc->numCpuBursts - ceil(smallestProc->burstIndex / 2) - 1;
					std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " completed a CPU burst; " << btg << " burst" << ((btg != 1) ? "s" : "") << " to go " << queueToStr(readyQueue) << '\n';
					std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " switching out of CPU; blocking on I/O until time " << smallestProc->waitingUntil << "ms " << queueToStr(readyQueue) << "\n";
				}
			}

			if (readyQueue.size() > 0)
			{
				readyQueue.front()->switchingUntil = sysClock + args->contextSwitchTime;
			}
			cswitches += 1;
			sysClock += csTimeSplit;
			runningProc = NULL;

			break;

		case WAITING:
			sysClock = smallestProc->waitingUntil;
			// move the process from the I/O to the queueueueueueueueue
			waitingQueue.pop();
			readyQueue.push_back(smallestProc);
			smallestProc->beginTurnaround(sysClock);
			smallestProc->state = READY;
			smallestProc->runningUntil = 0;
			smallestProc->switchingUntil = sysClock + csTimeSplit;

			if (debug || sysClock < 10000)
			{
				bool omitFirstInQueue = (switchingProc == NULL && runningProc == NULL && readyQueue.size() > 1 && readyQueue.front()->switchingUntil >= sysClock - csTimeSplit);
				std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " completed I/O; added to ready queue " << queueToStr(readyQueue, omitFirstInQueue) << '\n';
			}

			break;

		case PREEMPTED:
		{
			// the queue is empty
			if (readyQueue.size() == 0 && runningProc->timeRemaining)
			{
				sysClock = runningProc->runningUntil;
				runningProc->timeRemaining -= args->timeSliceValue;

				if (runningProc->timeRemaining <= args->timeSliceValue)
				{
					runningProc->runningUntil = sysClock + runningProc->timeRemaining;
					runningProc->timeRemaining = 0;
				}
				else
				{
					sysClock = runningProc->runningUntil;
					runningProc->runningUntil = sysClock + args->timeSliceValue;
				}

				if (debug || sysClock < 10000)
				{
					cout << "time " << sysClock << "ms: Time slice expired; no preemption because ready queue is empty [Q <empty>]" << endl;
				}

				break;
			}

			// process is in the queue
			if (readyQueue.size() > 0 && readyQueue.front() == smallestProc)
			{
				sysClock = smallestProc->switchingUntil;
				readyQueue.pop_front();
				runningProc = smallestProc;

				// context switching time done
				if (debug || sysClock < 10000)
				{
					cout << "time " << sysClock << "ms: Process " << smallestProc->name << " started using the CPU for remaining " << smallestProc->timeRemaining << "ms of " << smallestProc->bursts[smallestProc->burstIndex] << "ms burst " << queueToStr(readyQueue) << endl;
				}

				if (runningProc->timeRemaining <= args->timeSliceValue)
				{
					runningProc->runningUntil = sysClock + runningProc->timeRemaining;
					runningProc->timeRemaining = 0;
				}
				else
				{
					runningProc->runningUntil = sysClock + args->timeSliceValue;
				}
			}
			else
			{
				// process is currently running and will need to run again to finish
				sysClock = smallestProc->runningUntil;
				measurements.numContextSwitches.countOne(smallestProc);

				if (smallestProc->timeRemaining)
					smallestProc->timeRemaining -= args->timeSliceValue;
				else
					smallestProc->endTurnaround(sysClock);

				// NOT AN ELSE-IF
				if (smallestProc->numCpuBursts - ceil((smallestProc->burstIndex + 1) / 2) - 1 == 0 && !smallestProc->timeRemaining)
				{
					// exit the process
					smallestProc->endTurnaround(sysClock);
					std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " terminated " << queueToStr(readyQueue) << '\n';
				}
				else if (!smallestProc->timeRemaining)
				{
					smallestProc->runningUntil = 0;
					smallestProc->burstIndex++;

					runningProc->state = WAITING;
					smallestProc->waitingUntil = sysClock + smallestProc->bursts[smallestProc->burstIndex] + csTimeSplit;

					// move the process to either I/O wait (no CPU bc they alternate)
					waitingQueue.push(runningProc);

					if (debug || sysClock < 10000)
					{
						int btg = smallestProc->numCpuBursts - ceil(smallestProc->burstIndex / 2) - 1;
						std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " completed a CPU burst; " << btg << " burst" << ((btg != 1) ? "s" : "") << " to go " << queueToStr(readyQueue) << '\n';
						std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " switching out of CPU; blocking on I/O until time " << smallestProc->waitingUntil << "ms " << queueToStr(readyQueue) << "\n";
					}
				}
				else if (debug || sysClock < 10000)
				{
					cout << "time " << sysClock << "ms: Time slice expired; preempting process " << smallestProc->name << " with " << smallestProc->timeRemaining << "ms remaining " << queueToStr(readyQueue) << endl;
				}

				if (smallestProc->timeRemaining)
				{
					smallestProc->state = SWITCHINGOUT;
					smallestProc->switchingUntil = sysClock + csTimeSplit;
					switchingProc = smallestProc;
				}

				if (readyQueue.size() > 0)
				{
					readyQueue.front()->switchingUntil = sysClock + args->contextSwitchTime;
				}

				runningProc = NULL;

				cswitches += 1;

				if (waitingQueue.size() <= 0 || waitingQueue.top()->waitingUntil != sysClock)
					sysClock += csTimeSplit;
			}
			break;
		}

		case SWITCHINGOUT:
			// switching into the queue
			sysClock = smallestProc->switchingUntil;
			smallestProc->state = PREEMPTED;
			smallestProc->switchingUntil = 0;
			readyQueue.push_back(smallestProc);
			measurements.numPreemptions.countOne(smallestProc);
			switchingProc = NULL;
		}
	}

	std::cout << "time " << sysClock << "ms: Simulator ended for RR [Q <empty>]\n";

	measurements.timeElapsed = sysClock;
}