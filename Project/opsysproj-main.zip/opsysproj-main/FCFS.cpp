#include "everything.h"
using namespace std;

#define INTLIMIT numeric_limits<int>::max()

enum
{
	NOTINPROC,
	READY,
	RUNNING,
	WAITING
};

const char *queueToStr(const list<Process *> &readyQueue)
{
	if (readyQueue.size() == 0)
	{
		return "[Q <empty>]";
	}

	string s = "[Q ";
	printf("[Q ");
	int i = 0;

	for (Process *p : readyQueue)
	{
		i++;
		printf("%c", p->name);
		if (i != (int)readyQueue.size())
			printf(" ");
	}

	return "]";
}

struct CompareProcessPointers
{
	bool operator()(const Process *p1, const Process *p2) const
	{
		if (p1->burstIndex == -1 && p2->burstIndex == -1)
			return p1->arrivalTime < p2->arrivalTime;
		return p1->waitingUntil > p2->waitingUntil;
	}
};

void FCFS(const list<Process *> &p, const Arguments *const args, AlgorithmMeasurements &measurements)
{
	bool debug = false;

	list<Process *> readyQueue, unarrived(p);
	priority_queue<Process *, vector<Process *>, CompareProcessPointers> waitingQueue;
	Process *runningProc = NULL;

	// reset process state
	for (const auto p : unarrived)
	{
		p->resetVariables();
		p->burstIndex = -1;
	}

	int csTimeSplit = args->contextSwitchTime / 2;

	int sysClock = 0;

	unarrived.sort(CompareProcessPointers());

	printf("time 0ms: Simulator started for FCFS [Q <empty>]\n");
	Process *smallestProc;
	int smallestTime;

	while (runningProc != NULL || unarrived.size() || readyQueue.size() || waitingQueue.size())
	{
		// find the next process to do something
		if (unarrived.size() > 0)
		{
			smallestProc = unarrived.front();
			smallestTime = unarrived.front()->arrivalTime - sysClock;
		}
		else
		{
			smallestProc = NULL;
			smallestTime = INTLIMIT;
		}

		// check if the thing running has shorter time
		if (runningProc != NULL && (runningProc->runningUntil - sysClock + csTimeSplit) < smallestTime)
		{
			smallestTime = runningProc->runningUntil - sysClock + csTimeSplit;
			smallestProc = runningProc;
		}

		// check the ready queueueueueueueueeueueueueeue
		if (runningProc == NULL && readyQueue.size() > 0 && csTimeSplit < smallestTime)
		{
			smallestProc = readyQueue.front();
			smallestTime = csTimeSplit;
		}

		// check the waiting queueueueueeueueueueue
		if (waitingQueue.size() > 0 && (waitingQueue.top()->waitingUntil - sysClock) < smallestTime)
		{
			smallestTime = waitingQueue.top()->waitingUntil - sysClock;
			smallestProc = waitingQueue.top();
		}

		// deal with whatever the event is
		switch (smallestProc->state)
		{
		case NOTINPROC:
			sysClock = smallestProc->arrivalTime;
			smallestProc->switchingUntil = sysClock + csTimeSplit;

			// move the process into the ready queue
			readyQueue.push_back(smallestProc);

			smallestProc->beginTurnaround(sysClock);

			unarrived.pop_front();
			smallestProc->state = READY;
			std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " arrived; added to ready queue " << queueToStr(readyQueue) << '\n';
			break;

		case READY:
			// move the CPU (checking is done earlier)
			readyQueue.pop_front();

			runningProc = smallestProc;
			runningProc->state = RUNNING;
			runningProc->burstIndex++;
			sysClock = smallestProc->switchingUntil;

			if (debug || sysClock < 10000)
			{
				std::cout << "time " << smallestProc->switchingUntil << "ms: Process " << smallestProc->name << " started using the CPU for " << smallestProc->bursts[smallestProc->burstIndex] << "ms burst " << queueToStr(readyQueue) << '\n';
			}

			smallestProc->runningUntil = sysClock + smallestProc->bursts[smallestProc->burstIndex];
			break;

		case RUNNING:
			sysClock = smallestProc->runningUntil;
			smallestProc->burstIndex++;

			if ((int)smallestProc->totalBursts <= smallestProc->burstIndex)
			{
				// exit the process
				std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " terminated " << queueToStr(readyQueue) << '\n';
			}
			else
			{
				runningProc->state = WAITING;
				smallestProc->waitingUntil = sysClock + smallestProc->bursts[smallestProc->burstIndex] + csTimeSplit;

				// move the process to either I/O wait (no CPU bc they alternate)
				waitingQueue.push(runningProc);

				if (debug || sysClock < 10000)
				{
					int btg = smallestProc->numCpuBursts - ceil(smallestProc->burstIndex / 2) - 1;
					std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " completed a CPU burst; " << btg << " burst" << ((btg != 1) ? "s" : "") << " to go " << queueToStr(readyQueue) << '\n';
					std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " switching out of CPU; blocking on I/O until time " << smallestProc->waitingUntil << "ms " << queueToStr(readyQueue) << "\n";
				}

			}

			if (readyQueue.size() > 0)
				readyQueue.front()->switchingUntil = sysClock + args->contextSwitchTime;
			
			sysClock += csTimeSplit;
			runningProc = NULL;

			smallestProc->endTurnaround(sysClock);

			measurements.numContextSwitches.countOne(smallestProc);

			break;

		case WAITING:
			sysClock = smallestProc->waitingUntil;
			// move the process from the I/O to the queueueueueueueueue
			waitingQueue.pop();
			readyQueue.push_back(smallestProc);

			smallestProc->beginTurnaround(sysClock);

			smallestProc->state = READY;
			smallestProc->runningUntil = 0;
			smallestProc->switchingUntil = sysClock + csTimeSplit;

			if (debug || sysClock < 10000)
			{
				std::cout << "time " << sysClock << "ms: Process " << smallestProc->name << " completed I/O; added to ready queue " << queueToStr(readyQueue) << '\n';
			}
		}
	}

	std::cout << "time " << sysClock << "ms: Simulator ended for FCFS [Q <empty>]\n";

	measurements.timeElapsed = sysClock;
}