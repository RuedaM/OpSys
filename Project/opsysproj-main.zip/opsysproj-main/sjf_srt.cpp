#include "sjf_srt.h"

bool SjfBurstComparer::operator()(const Process *const p1, const Process *const p2) const
{
	return (p1->tau != p2->tau) ? (p1->tau > p2->tau) : (p1->name > p2->name);
}

bool SrtBurstComparer::operator()(const Process *const p1, const Process *const p2) const
{
	return (p1->currentTau != p2->currentTau) ? (p1->currentTau > p2->currentTau) : (p1->name > p2->name);
}

std::ostream &operator<<(std::ostream &ostr, SjfReadyQueue queue)
{
	ostr << "[Q ";
	if (queue.empty())
		ostr << "<empty>";
	else
	{
		bool empty = false;
		while (!empty)
		{
			ostr << queue.top()->name;
			queue.pop();
			if (!(empty = queue.empty()))
				ostr << ' ';
		}
	}
	return ostr << ']';
}

std::ostream &operator<<(std::ostream &ostr, SrtReadyQueue queue)
{
	ostr << "[Q ";
	if (queue.empty())
		ostr << "<empty>";
	else
	{
		bool empty = false;
		while (!empty)
		{
			ostr << queue.top()->name;
			queue.pop();
			if (!(empty = queue.empty()))
				ostr << ' ';
		}
	}
	return ostr << ']';
}

bool all_completed(const std::list<Process *> &processes)
{
	for (const auto p : processes)
		if (p->state != COMPLETED)
			return false;
	return true;
}

int currentTime;

int earliestEventTime(const Process *const p)
{
	switch (p->state)
	{
	case NOTINCPU:
		return p->arrivalTime;
	case READY:
		return currentTime;
	case RUNNING:
		return p->runningUntil;
	case WAITING:
		return p->waitingUntil;
	case SWITCHING_OUT:
	case SWITCHING_IN:
		return p->switchingUntil;
	case COMPLETED:
		return __INT_MAX__;
	default:
		std::exit(1);
	}
}

bool earlierEvent(const Process *const p1, const Process *const p2)
{
	if (!p1 || !p2)
		return false;

	// Lower event time comes first.
	int eventTime1 = earliestEventTime(p1);
	int eventTime2 = earliestEventTime(p2);

	if (eventTime1 == eventTime2)
	{
		if (p1->state == p2->state)
			return p1->name < p2->name;
		return p1->state < p2->state;
	}

	return eventTime1 < eventTime2;
}

Process *earliestEventProcess(const std::list<Process *> &processes, Process *const runningProcess)
{
	Process *smallest = (runningProcess == NULL) ? processes.front() : runningProcess;
	for (auto &p : processes)
	{
		if (runningProcess && p->state == READY)
			continue;
		if (earlierEvent(p, smallest))
			smallest = p;
	}
	return smallest;
}
