#include "everything.h"

extern std::ofstream simout;
Total3 totalCpuBursts;
Average3 avgCpuBurstTime;

void process_measurements(const std::list<Process *> &processes, AlgorithmMeasurements &measurements, const char *const algorithmName, const Arguments &args)
{
	simout << "Algorithm " << algorithmName << '\n';

	int cpuUtilTime = 0;
	for (const auto p : processes)
		cpuUtilTime += p->cpuBurstTimeSum;
	double cpuUtil = 100 * ((double)cpuUtilTime / (double)measurements.timeElapsed);
	cpuUtil = std::ceil(cpuUtil * 1000) / 1000;
	simout << "-- CPU utilization: " << std::fixed << std::setprecision(3) << cpuUtil << "%\n";

	simout << "-- average CPU burst time: " << std::fixed << std::setprecision(3) << avgCpuBurstTime.forAllProcesses << " ms (" << std::fixed << std::setprecision(3) << avgCpuBurstTime.forCpuProcesses << " ms/" << std::fixed << std::setprecision(3) << avgCpuBurstTime.forIoProcesses << " ms)\n";

	// avg wait time across i/o, cpu, and all processes
	Total3 waitTimeSum;
	for (const auto p : processes)
	{
		waitTimeSum.forAllProcesses += p->turnaroundTimeSum - p->cpuBurstTimeSum - p->numPreemptions * args.contextSwitchTime;
		if (p->isIO)
			waitTimeSum.forIoProcesses += p->turnaroundTimeSum - p->cpuBurstTimeSum - p->numPreemptions * args.contextSwitchTime;
		else
			waitTimeSum.forCpuProcesses += p->turnaroundTimeSum - p->cpuBurstTimeSum - p->numPreemptions * args.contextSwitchTime;
	}
	Average3 avgWaitTime;
	avgWaitTime.calcAverages(waitTimeSum, totalCpuBursts);
	avgWaitTime.forAllProcesses -= args.contextSwitchTime;
	avgWaitTime.forCpuProcesses -= args.contextSwitchTime;
	avgWaitTime.forIoProcesses -= args.contextSwitchTime;
	avgWaitTime.roundAllTo3Places();

	simout << "-- average wait time: " << std::fixed << std::setprecision(3) << avgWaitTime.forAllProcesses << " ms (" << std::fixed << std::setprecision(3) << avgWaitTime.forCpuProcesses << " ms/" << std::fixed << std::setprecision(3) << avgWaitTime.forIoProcesses << " ms)\n";

	// avg turnaround time across i/o, cpu, and all processes
	Total3 turnaroundTimeSum;
	for (const auto p : processes)
	{
		turnaroundTimeSum.forAllProcesses += p->turnaroundTimeSum;
		if (p->isIO)
			turnaroundTimeSum.forIoProcesses += p->turnaroundTimeSum;
		else
			turnaroundTimeSum.forCpuProcesses += p->turnaroundTimeSum;
	}
	Average3 avgTurnaroundTime;
	avgTurnaroundTime.calcAverages(turnaroundTimeSum, totalCpuBursts);
	avgTurnaroundTime.roundAllTo3Places();

	simout << "-- average turnaround time: " << std::fixed << std::setprecision(3) << avgTurnaroundTime.forAllProcesses << " ms (" << std::fixed << std::setprecision(3) << avgTurnaroundTime.forCpuProcesses << " ms/" << std::fixed << std::setprecision(3) << avgTurnaroundTime.forIoProcesses << " ms)\n";

	simout << "-- number of context switches: " << measurements.numContextSwitches.forAllProcesses << " (" << measurements.numContextSwitches.forCpuProcesses << '/' << measurements.numContextSwitches.forIoProcesses << ")\n";
	simout << "-- number of preemptions: " << measurements.numPreemptions.forAllProcesses << " (" << measurements.numPreemptions.forCpuProcesses << '/' << measurements.numPreemptions.forIoProcesses << ")\n\n";

	// reset measurements after for next algorithm
	measurements.reset();
}

void calc_avg_cpu_burst_time(const std::list<Process *> &processes)
{
	// count total cpu bursts for all, i/o-bound, and cpu-bound processes
	for (const auto p : processes)
	{
		totalCpuBursts.forAllProcesses += p->numCpuBursts;
		if (p->isIO)
			totalCpuBursts.forIoProcesses += p->numCpuBursts;
		else
			totalCpuBursts.forCpuProcesses += p->numCpuBursts;
	}

	Total3 cpuBurstTimeSum;

	// sum up cpu burst times per the 3 three criteria
	for (const auto p : processes)
	{
		cpuBurstTimeSum.forAllProcesses += p->cpuBurstTimeSum;
		if (p->isIO)
			cpuBurstTimeSum.forIoProcesses += p->cpuBurstTimeSum;
		else
			cpuBurstTimeSum.forCpuProcesses += p->cpuBurstTimeSum;
	}

	// now calc the averages
	avgCpuBurstTime.calcAverages(cpuBurstTimeSum, totalCpuBursts);
	avgCpuBurstTime.roundAllTo3Places();
}
